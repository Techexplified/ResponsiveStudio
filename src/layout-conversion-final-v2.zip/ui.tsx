import { render } from "@create-figma-plugin/ui"
import { h } from "preact"
import { useEffect, useMemo, useState } from "preact/hooks"
import "!./output.css"
import ResponsiveSidebar from "./components/ResponsiveSidebar"
import Editor from "./components/Editor"
import ExportFramePanel, { type ExportFrameSnapshot } from "./components/ExportFramePanel"
import { convertFrameLayout } from "./components/editorModel"
import type { FigmaSerializedFrame, LayoutConversionDirection, PluginToUiMessage } from "./frameSchema"
import { denormalizeFigmaJson, deserializeNormalizedJson } from "./normalizedFrameSchema"

function Plugin() {
  const [sourceFrame, setSourceFrame] = useState<FigmaSerializedFrame | null>(null)
  const [sourceType, setSourceType] = useState<"figma" | "json" | null>(null)
  const [direction, setDirection] = useState<LayoutConversionDirection>("row-to-column")
  const [editedConvertedFrame, setEditedConvertedFrame] = useState<FigmaSerializedFrame | null>(null)
  const [importError, setImportError] = useState("")
  const [jsonImportError, setJsonImportError] = useState("")
  const [undoStack, setUndoStack] = useState<FigmaSerializedFrame[]>([])
  const [redoStack, setRedoStack] = useState<FigmaSerializedFrame[]>([])
  const [snapshot, setSnapshot] = useState<ExportFrameSnapshot | null>(null)
  const [isExportOpen, setIsExportOpen] = useState(false)

  const automaticallyConverted = useMemo(
    () => sourceFrame == null ? null : convertFrameLayout(sourceFrame, direction),
    [sourceFrame, direction]
  )
  const convertedFrame = editedConvertedFrame ?? automaticallyConverted

  useEffect(() => {
    setEditedConvertedFrame(null)
    setUndoStack([])
    setRedoStack([])
  }, [sourceFrame, direction])

  useEffect(() => {
    function receive(event: MessageEvent<{ pluginMessage?: PluginToUiMessage }>) {
      const message = event.data.pluginMessage
      if (!message) return
      if (message.type === "frame-imported") {
        setSourceFrame(message.payload)
        setSourceType("figma")
        setImportError("")
        setJsonImportError("")
      } else if (message.type === "import-error") {
        setImportError(message.message)
      }
    }
    window.addEventListener("message", receive)
    return () => window.removeEventListener("message", receive)
  }, [])

  function clearFrame() {
    setSourceFrame(null)
    setSourceType(null)
    setEditedConvertedFrame(null)
    setUndoStack([])
    setRedoStack([])
    setSnapshot(null)
    setIsExportOpen(false)
  }

  function importJson(value: string): boolean {
    const result = deserializeNormalizedJson(value)
    if (!result.ok) {
      setJsonImportError(result.errors.map((issue) => `${issue.path}: ${issue.message}`).join("\n"))
      return false
    }
    setSourceFrame(denormalizeFigmaJson(result.value))
    setSourceType("json")
    setJsonImportError("")
    setImportError("")
    return true
  }

  function changeConvertedFrame(next: FigmaSerializedFrame) {
    if (convertedFrame) setUndoStack((stack) => [...stack.slice(-29), clone(convertedFrame)])
    setRedoStack([])
    setEditedConvertedFrame(next)
  }

  function undo() {
    if (!convertedFrame || undoStack.length === 0) return
    const previous = undoStack[undoStack.length - 1]
    setUndoStack((stack) => stack.slice(0, -1))
    setRedoStack((stack) => [...stack.slice(-29), clone(convertedFrame)])
    setEditedConvertedFrame(clone(previous))
  }

  function redo() {
    if (!convertedFrame || redoStack.length === 0) return
    const next = redoStack[redoStack.length - 1]
    setRedoStack((stack) => stack.slice(0, -1))
    setUndoStack((stack) => [...stack.slice(-29), clone(convertedFrame)])
    setEditedConvertedFrame(clone(next))
  }

  function exportFrame() {
    if (!sourceFrame || !convertedFrame || !sourceType) return
    if (sourceType === "figma") {
      parent.postMessage({ pluginMessage: { type: "convert-and-export-frame", payload: { sourceFrameId: sourceFrame.id, direction } } }, "*")
    } else {
      parent.postMessage({ pluginMessage: { type: "export-converted-json-frame", payload: { frame: convertedFrame } } }, "*")
    }
    setSnapshot({ id: `${Date.now()}`, appliedAt: new Date().toISOString(), direction, frame: clone(convertedFrame) })
    setIsExportOpen(true)
  }

  return <div class="flex h-screen overflow-hidden bg-gray-100">
    <ResponsiveSidebar importedFrame={sourceFrame} importError={importError} jsonImportError={jsonImportError} direction={direction} onDirectionChange={setDirection} onClearFrame={clearFrame} onImportJson={importJson} onExport={exportFrame} />
    <Editor sourceFrame={sourceFrame} convertedFrame={convertedFrame} canUndo={undoStack.length > 0} canRedo={redoStack.length > 0} onUndo={undo} onRedo={redo} onFrameChange={changeConvertedFrame} />
    <ExportFramePanel snapshot={snapshot} isOpen={isExportOpen} onClose={() => setIsExportOpen(false)} />
  </div>
}

function clone<T>(value: T): T { return JSON.parse(JSON.stringify(value)) as T }
export default render(Plugin)

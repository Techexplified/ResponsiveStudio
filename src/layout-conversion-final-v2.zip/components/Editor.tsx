import { h } from "preact"
import { useEffect, useState } from "preact/hooks"
import type { FigmaSerializedFrame } from "../frameSchema"
import FramePreview from "./FramePreview"
import ExportPreviewDrawer from "./ExportPreviewDrawer"
import LayerPanel from "./LayerPanel"
import { findNode } from "./editorModel"

export default function Editor({ sourceFrame, convertedFrame, canUndo, canRedo, onUndo, onRedo, onFrameChange }: { sourceFrame: FigmaSerializedFrame | null; convertedFrame: FigmaSerializedFrame | null; canUndo: boolean; canRedo: boolean; onUndo: () => void; onRedo: () => void; onFrameChange: (frame: FigmaSerializedFrame) => void }) {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(convertedFrame?.id ?? null)
  useEffect(() => { if (!convertedFrame) setSelectedNodeId(null); else if (!selectedNodeId || !findNode(convertedFrame, selectedNodeId)) setSelectedNodeId(convertedFrame.id) }, [convertedFrame])
  if (!sourceFrame || !convertedFrame) return <main class="flex min-w-0 flex-1 items-center justify-center bg-gray-100"><div class="text-center"><h2 class="text-lg font-bold text-gray-900">Import a frame to begin</h2><p class="mt-2 text-sm text-gray-500">The converter will recursively flip matching Auto Layout frames.</p></div></main>
  return <main class="flex min-w-0 flex-1 flex-col bg-gray-100"><header class="flex h-16 items-center justify-between border-b border-gray-200 bg-white px-5"><div><h2 class="text-sm font-bold text-gray-900">{sourceFrame.name}</h2><p class="mt-1 text-xs text-gray-500">Source and converted output use one serialized frame state</p></div><div class="flex gap-2"><button disabled={!canUndo} onClick={onUndo} class="rounded-lg border px-3 py-2 text-xs font-semibold disabled:opacity-40">Undo</button><button disabled={!canRedo} onClick={onRedo} class="rounded-lg border px-3 py-2 text-xs font-semibold disabled:opacity-40">Redo</button></div></header><div class="flex min-h-0 flex-1"><div class="grid min-w-0 flex-1 grid-cols-2 divide-x divide-gray-200"><FramePreview frame={sourceFrame} selectedNodeId={null} onSelect={() => undefined} title="Original"/><ExportPreviewDrawer frame={convertedFrame} selectedNodeId={selectedNodeId} onSelect={setSelectedNodeId}/></div><div class="w-72 shrink-0"><LayerPanel frame={convertedFrame} selectedNodeId={selectedNodeId} onSelect={setSelectedNodeId} onFrameChange={onFrameChange}/></div></div></main>
}

import { h } from "preact"
import type { LayoutConversionDirection } from "../frameSchema"

export default function LayoutRules({ value, onChange }: { value: LayoutConversionDirection; onChange: (value: LayoutConversionDirection) => void }) {
  return (
    <div class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
      <h3 class="text-sm font-bold text-gray-900">Layout direction</h3>
      <p class="mt-1 text-xs leading-5 text-gray-500">Applies recursively to every matching Auto Layout frame.</p>
      <div class="mt-4 grid grid-cols-2 gap-2">
        <DirectionButton active={value === "row-to-column"} onClick={() => onChange("row-to-column")} label="Row → Column" />
        <DirectionButton active={value === "column-to-row"} onClick={() => onChange("column-to-row")} label="Column → Row" />
      </div>
    </div>
  )
}

function DirectionButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return <button type="button" onClick={onClick} class={`rounded-xl border px-3 py-3 text-sm font-semibold transition ${active ? "border-teal-700 bg-teal-50 text-teal-800" : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"}`}>{label}</button>
}

import { h } from "preact"
import type { FigmaSerializedFrame, FigmaSerializedNode } from "../frameSchema"
import { findNode, readLayoutMode, updateNode } from "./editorModel"
import FlexLayoutPanel from "./FlexLayoutPanel"

export default function LayerPanel({ frame, selectedNodeId, onSelect, onFrameChange }: { frame: FigmaSerializedFrame; selectedNodeId: string | null; onSelect: (id: string) => void; onFrameChange: (frame: FigmaSerializedFrame) => void }) {
  const selected = selectedNodeId ? findNode(frame, selectedNodeId) : null
  return <aside class="flex h-full flex-col border-l border-gray-200 bg-white"><div class="border-b border-gray-200 p-4"><h3 class="text-sm font-bold text-gray-900">Layers</h3></div><div class="min-h-0 flex-1 overflow-auto p-2"><Layer node={frame} selectedNodeId={selectedNodeId} onSelect={onSelect} depth={0} /></div>{selected && <FlexLayoutPanel node={selected} onChange={(next) => onFrameChange(updateNode(frame, selected.id, () => next))} />}</aside>
}
function Layer({ node, selectedNodeId, onSelect, depth }: { node: FigmaSerializedNode; selectedNodeId: string | null; onSelect: (id: string) => void; depth: number }) {
  return <div><button type="button" onClick={() => onSelect(node.id)} class={`flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-xs ${selectedNodeId === node.id ? "bg-teal-50 text-teal-800" : "text-gray-700 hover:bg-gray-50"}`} style={{ paddingLeft: `${8 + depth * 14}px` }}><span class="min-w-0 flex-1 truncate font-semibold">{node.name}</span><span class="text-[10px] text-gray-400">{readLayoutMode(node)}</span></button>{node.children.map((child) => <Layer key={child.id} node={child} selectedNodeId={selectedNodeId} onSelect={onSelect} depth={depth + 1} />)}</div>
}

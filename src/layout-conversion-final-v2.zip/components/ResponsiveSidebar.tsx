import { h } from "preact"
import { useState } from "preact/hooks"
import type { FigmaSerializedFrame, LayoutConversionDirection } from "../frameSchema"
import LayoutRules from "./LayoutRules"

export default function ResponsiveSidebar({ importedFrame, importError, jsonImportError, direction, onDirectionChange, onClearFrame, onImportJson, onExport }: {
  importedFrame: FigmaSerializedFrame | null
  importError: string
  jsonImportError: string
  direction: LayoutConversionDirection
  onDirectionChange: (value: LayoutConversionDirection) => void
  onClearFrame: () => void
  onImportJson: (value: string) => boolean
  onExport: () => void
}) {
  const [json, setJson] = useState("")
  const [showJson, setShowJson] = useState(false)
  return (
    <aside class="flex h-full w-80 shrink-0 flex-col border-r border-gray-200 bg-gray-50">
      <div class="border-b border-gray-200 bg-white p-5"><h1 class="text-lg font-bold text-gray-900">Layout Converter</h1><p class="mt-1 text-xs text-gray-500">Recursive Row / Column conversion</p></div>
      <div class="min-h-0 flex-1 space-y-4 overflow-auto p-4">
        <div class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
          <button type="button" onClick={() => parent.postMessage({ pluginMessage: { type: "import-selected-frame" } }, "*")} class="w-full rounded-xl bg-gray-900 px-4 py-3 text-sm font-bold text-white hover:bg-black">Import selected frame</button>
          <button type="button" onClick={() => setShowJson((v) => !v)} class="mt-2 w-full rounded-xl border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700">{showJson ? "Hide JSON import" : "Import JSON"}</button>
          {showJson && <div class="mt-3"><textarea value={json} onInput={(e) => setJson(e.currentTarget.value)} class="h-32 w-full resize-none rounded-lg border border-gray-200 p-2 font-mono text-xs" placeholder="Paste normalized or schema v1 JSON" /><button type="button" onClick={() => onImportJson(json)} class="mt-2 w-full rounded-lg bg-teal-700 px-3 py-2 text-sm font-bold text-white">Load JSON</button></div>}
          {(importError || jsonImportError) && <p class="mt-3 text-xs font-medium text-red-600">{importError || jsonImportError}</p>}
          {importedFrame && <div class="mt-4 rounded-xl bg-gray-50 p-3"><div class="truncate text-sm font-bold text-gray-900">{importedFrame.name}</div><div class="mt-1 text-xs text-gray-500">{Math.round(importedFrame.geometry.width)} × {Math.round(importedFrame.geometry.height)}</div><button type="button" onClick={onClearFrame} class="mt-2 text-xs font-semibold text-red-600">Remove</button></div>}
        </div>
        <LayoutRules value={direction} onChange={onDirectionChange} />
      </div>
      <div class="border-t border-gray-200 bg-white p-4"><button type="button" disabled={!importedFrame} onClick={onExport} class="w-full rounded-xl bg-teal-700 px-4 py-3 text-sm font-bold text-white enabled:hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-40">Convert & Export</button></div>
    </aside>
  )
}

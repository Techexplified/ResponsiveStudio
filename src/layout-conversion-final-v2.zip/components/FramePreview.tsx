import { h } from "preact"
import type { FigmaSerializedFrame, FigmaSerializedNode } from "../frameSchema"
import { getCornerRadius, getSolidFillColor, readLayoutMode } from "./editorModel"

export default function FramePreview({ frame, selectedNodeId, onSelect, title = "Preview" }: { frame: FigmaSerializedFrame; selectedNodeId: string | null; onSelect: (id: string) => void; title?: string }) {
  const scale = Math.min(1, 620 / Math.max(frame.geometry.width, 1), 650 / Math.max(frame.geometry.height, 1))
  return <section class="flex min-h-0 flex-1 flex-col"><div class="border-b border-gray-200 bg-white px-4 py-3 text-xs font-bold uppercase tracking-wide text-gray-500">{title}</div><div class="min-h-0 flex-1 overflow-auto bg-gray-100 p-6"><div class="mx-auto w-fit"><div style={{ width: `${frame.geometry.width * scale}px`, height: `${frame.geometry.height * scale}px` }}><NodeView node={frame} selectedNodeId={selectedNodeId} onSelect={onSelect} scale={scale} isRoot /></div></div></div></section>
}

function NodeView({ node, selectedNodeId, onSelect, scale, isRoot = false }: { node: FigmaSerializedNode; selectedNodeId: string | null; onSelect: (id: string) => void; scale: number; isRoot?: boolean }) {
  const mode = readLayoutMode(node)
  const padding = node.layout.padding ?? { top: 0, right: 0, bottom: 0, left: 0 }
  const isFlow = mode === "HORIZONTAL" || mode === "VERTICAL"
  const style: Record<string, string | number | undefined> = {
    position: isRoot ? "relative" : undefined,
    width: `${Math.max(1, node.geometry.width) * scale}px`,
    height: `${Math.max(1, node.geometry.height) * scale}px`,
    background: getSolidFillColor(node.style.fills) ?? (node.type === "TEXT" ? "transparent" : "rgba(255,255,255,.75)"),
    borderRadius: `${getCornerRadius(node) * scale}px`,
    opacity: node.visible ? node.style.opacity ?? 1 : 0.25,
    outline: selectedNodeId === node.id ? "2px solid #0f766e" : node.type === "FRAME" || node.children.length ? "1px solid rgba(15,23,42,.12)" : undefined,
    outlineOffset: "-1px",
    overflow: "hidden",
    boxSizing: "border-box",
    display: isFlow ? "flex" : "block",
    flexDirection: mode === "HORIZONTAL" ? "row" : mode === "VERTICAL" ? "column" : undefined,
    gap: isFlow ? `${(node.layout.itemSpacing ?? 0) * scale}px` : undefined,
    padding: isFlow ? `${padding.top * scale}px ${padding.right * scale}px ${padding.bottom * scale}px ${padding.left * scale}px` : undefined,
    justifyContent: isFlow ? axisAlign(node.layout.primaryAxisAlignItems) : undefined,
    alignItems: isFlow ? crossAlign(node.layout.counterAxisAlignItems) : undefined
  }
  return <div title={`${node.name} · ${mode}`} onClick={(event) => { event.stopPropagation(); onSelect(node.id) }} style={style}>
    {node.type === "TEXT" && <span style={{ fontSize: `${(typeof node.text?.fontSize === "number" ? node.text.fontSize : 14) * scale}px`, whiteSpace: "pre-wrap" }}>{node.text?.characters ?? node.name}</span>}
    {node.children.map((child) => isFlow
      ? <NodeView key={child.id} node={child} selectedNodeId={selectedNodeId} onSelect={onSelect} scale={scale} />
      : <div key={child.id} style={{ position: "absolute", left: `${child.geometry.x * scale}px`, top: `${child.geometry.y * scale}px` }}><NodeView node={child} selectedNodeId={selectedNodeId} onSelect={onSelect} scale={scale} /></div>)}
  </div>
}

function axisAlign(value?: string): string {
  if (value === "CENTER") return "center"
  if (value === "MAX") return "flex-end"
  if (value === "SPACE_BETWEEN") return "space-between"
  return "flex-start"
}
function crossAlign(value?: string): string {
  if (value === "CENTER") return "center"
  if (value === "MAX") return "flex-end"
  if (value === "STRETCH") return "stretch"
  return "flex-start"
}

import { h } from "preact"
import type { FigmaSerializedFrame, LayoutConversionDirection } from "../frameSchema"
import { normalizeFigmaJson } from "../normalizedFrameSchema"

export type ExportFrameSnapshot = { id: string; appliedAt: string; direction: LayoutConversionDirection; frame: FigmaSerializedFrame }
export default function ExportFramePanel({ snapshot, isOpen, onClose }: { snapshot: ExportFrameSnapshot | null; isOpen: boolean; onClose: () => void }) {
  const payload = snapshot ? { schemaVersion: 2, exportType: "layout-conversion", direction: snapshot.direction, appliedAt: snapshot.appliedAt, root: normalizeFigmaJson(snapshot.frame).root } : null
  return <aside class={`fixed right-0 top-0 z-50 flex h-screen w-[420px] max-w-full flex-col border-l border-gray-200 bg-white shadow-2xl transition-transform ${isOpen ? "translate-x-0" : "translate-x-full"}`}><header class="flex h-16 items-center justify-between border-b px-5"><div><h2 class="text-sm font-bold">Export snapshot</h2><p class="text-xs text-gray-500">Converted frame JSON</p></div><button onClick={onClose} class="rounded px-2 py-1">×</button></header><pre class="min-h-0 flex-1 overflow-auto p-4 text-xs">{payload ? JSON.stringify(payload, null, 2) : "No export yet."}</pre></aside>
}

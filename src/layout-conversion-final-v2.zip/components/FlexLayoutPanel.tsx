import { h } from "preact"
import type { FigmaSerializedNode } from "../frameSchema"
import { isAutoLayoutNode, readLayoutMode, setNodeLayoutDirection } from "./editorModel"

export default function FlexLayoutPanel({ node, onChange }: { node: FigmaSerializedNode; onChange: (node: FigmaSerializedNode) => void }) {
  if (!isAutoLayoutNode(node)) return <div class="p-4 text-xs text-gray-500">This layer is not an Auto Layout container.</div>
  const mode = readLayoutMode(node)
  return <div class="space-y-3 border-t border-gray-200 p-4"><div><div class="text-xs font-bold uppercase tracking-wide text-gray-500">Selected direction</div><div class="mt-2 grid grid-cols-2 gap-2"><button type="button" onClick={() => onChange(setNodeLayoutDirection(node, "HORIZONTAL"))} class={`rounded-lg border px-3 py-2 text-xs font-bold ${mode === "HORIZONTAL" ? "border-teal-700 bg-teal-50 text-teal-800" : "border-gray-200"}`}>Row</button><button type="button" onClick={() => onChange(setNodeLayoutDirection(node, "VERTICAL"))} class={`rounded-lg border px-3 py-2 text-xs font-bold ${mode === "VERTICAL" ? "border-teal-700 bg-teal-50 text-teal-800" : "border-gray-200"}`}>Column</button></div></div><div class="grid grid-cols-2 gap-2 text-xs text-gray-600"><div class="rounded-lg bg-gray-50 p-2">Gap<br/><strong>{node.layout.itemSpacing ?? 0}px</strong></div><div class="rounded-lg bg-gray-50 p-2">Children<br/><strong>{node.children.length}</strong></div></div></div>
}

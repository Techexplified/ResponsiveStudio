import type { FigmaSerializedFrame, FigmaSerializedNode, LayoutConversionDirection } from "../frameSchema"

export function findNode(node: FigmaSerializedNode, id: string): FigmaSerializedNode | null {
  if (node.id === id) return node
  for (const child of node.children) {
    const found = findNode(child, id)
    if (found) return found
  }
  return null
}

export function updateNode<T extends FigmaSerializedNode>(node: T, id: string, updater: (node: FigmaSerializedNode) => FigmaSerializedNode): T {
  if (node.id === id) return updater(node) as T
  return { ...node, children: node.children.map((child) => updateNode(child, id, updater)) } as T
}

export const EXPORTED_ROOT_WIDTH_RATIO = 0.9

export function convertFrameLayout(frame: FigmaSerializedFrame, direction: LayoutConversionDirection): FigmaSerializedFrame {
  const converted = convertNodeLayout(structuredCloneSafe(frame), direction) as FigmaSerializedFrame
  const width = Math.max(1, Math.round(frame.geometry.width * EXPORTED_ROOT_WIDTH_RATIO))

  return {
    ...converted,
    geometry: {
      ...converted.geometry,
      width
    },
    layout: {
      ...converted.layout,
      layoutSizingHorizontal: "FIXED",
      ...(readLayoutMode(converted) === "HORIZONTAL"
        ? { primaryAxisSizingMode: "FIXED" as const }
        : readLayoutMode(converted) === "VERTICAL"
          ? { counterAxisSizingMode: "FIXED" as const }
          : {})
    }
  }
}

export function convertNodeLayout(node: FigmaSerializedNode, direction: LayoutConversionDirection): FigmaSerializedNode {
  const children = node.children.map((child) => convertNodeLayout(child, direction))
  const current = readLayoutMode(node)
  const next = direction === "row-to-column"
    ? current === "HORIZONTAL" ? "VERTICAL" : current
    : current === "VERTICAL" ? "HORIZONTAL" : current

  if (next === current) return { ...node, children }

  return {
    ...node,
    children,
    layout: {
      ...node.layout,
      isAutoLayout: true,
      layoutMode: next,
      autoLayoutDirection: next
    }
  }
}

export function setNodeLayoutDirection(node: FigmaSerializedNode, mode: "HORIZONTAL" | "VERTICAL"): FigmaSerializedNode {
  return {
    ...node,
    layout: {
      ...node.layout,
      isAutoLayout: true,
      layoutMode: mode,
      autoLayoutDirection: mode
    }
  }
}

export function readLayoutMode(node: FigmaSerializedNode): "NONE" | "HORIZONTAL" | "VERTICAL" | "GRID" {
  const value = node.layout.layoutMode ?? node.layout.autoLayoutDirection
  return value === "HORIZONTAL" || value === "VERTICAL" || value === "GRID" ? value : "NONE"
}

export function isAutoLayoutNode(node: FigmaSerializedNode): boolean {
  const mode = readLayoutMode(node)
  return node.layout.isAutoLayout === true && (mode === "HORIZONTAL" || mode === "VERTICAL")
}

export function getSolidFillColor(value: unknown): string | null {
  if (!Array.isArray(value)) return null
  const paint = value.find((item) => item && typeof item === "object" && (item as { type?: string }).type === "SOLID") as { color?: { r?: number; g?: number; b?: number }; opacity?: number } | undefined
  if (!paint?.color) return null
  const toByte = (n: number | undefined) => Math.round(Math.max(0, Math.min(1, n ?? 0)) * 255)
  return `rgba(${toByte(paint.color.r)}, ${toByte(paint.color.g)}, ${toByte(paint.color.b)}, ${paint.opacity ?? 1})`
}

export function getCornerRadius(node: FigmaSerializedNode): number {
  return typeof node.style.cornerRadius === "number" ? node.style.cornerRadius : 0
}

function structuredCloneSafe<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

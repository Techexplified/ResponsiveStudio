import { h } from "preact"
import type { FigmaSerializedFrame } from "../frameSchema"
import FramePreview from "./FramePreview"

export default function ExportPreviewDrawer({ frame, selectedNodeId, onSelect }: { frame: FigmaSerializedFrame; selectedNodeId: string | null; onSelect: (id: string) => void }) {
  return <FramePreview frame={frame} selectedNodeId={selectedNodeId} onSelect={onSelect} title="Converted preview" />
}

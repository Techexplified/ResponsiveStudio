import { showUI } from "@create-figma-plugin/utilities"
import type {
  FigmaJsonValue,
  FigmaSerializedFrame,
  FigmaSerializedNode,
  LayoutConversionDirection,
  PluginToUiMessage,
  UiToPluginMessage
} from "./frameSchema"

type ImportableFrameNode = FrameNode | ComponentNode | InstanceNode
type AutoLayoutSceneNode = FrameNode | ComponentNode | InstanceNode

const EXPORTED_ROOT_WIDTH_RATIO = 0.9

type Bounds = {
  x: number
  y: number
  width: number
  height: number
  right: number
  bottom: number
  centerX: number
  centerY: number
}

export default function () {
  showUI({ height: 900, width: 1400 })

  figma.ui.onmessage = (message: UiToPluginMessage) => {
    if (message.type === "import-selected-frame") {
      importSelectedFrame()
      return
    }

    if (message.type === "convert-and-export-frame") {
      convertAndExportFrame(message.payload.sourceFrameId, message.payload.direction).catch(reportError)
      return
    }

    if (message.type === "export-converted-json-frame") {
      exportConvertedJsonFrame(message.payload.frame).catch(reportError)
    }
  }
}

function reportError(error: unknown) {
  figma.notify(error instanceof Error ? error.message : "The frame could not be exported.")
}

function importSelectedFrame() {
  const [selected] = figma.currentPage.selection
  if (!selected || !isImportableFrameNode(selected)) {
    sendToUi({ type: "import-error", message: "Select a frame, component, or instance first." })
    return
  }
  sendToUi({ type: "frame-imported", payload: serializeFrame(selected) })
  figma.notify(`Imported "${selected.name}"`)
}

async function convertAndExportFrame(sourceFrameId: string, direction: LayoutConversionDirection) {
  const source = await figma.getNodeByIdAsync(sourceFrameId)
  if (!source || !isImportableFrameNode(source)) {
    throw new Error("The original Figma frame is unavailable. Import it again.")
  }

  const clone = source.clone()
  clone.name = `${source.name} / ${direction === "row-to-column" ? "Column" : "Row"}`
  convertFigmaNodeLayoutRecursively(clone, direction)
  setExportedRootWidth(clone, source.width * EXPORTED_ROOT_WIDTH_RATIO)
  clone.x = source.x + source.width + 80
  clone.y = source.y
  figma.currentPage.selection = [clone]
  figma.viewport.scrollAndZoomIntoView([clone])
  figma.notify(`Converted ${direction === "row-to-column" ? "rows to columns" : "columns to rows"}.`)
}

function setExportedRootWidth(node: ImportableFrameNode, requestedWidth: number) {
  const width = Math.max(1, Math.round(requestedWidth))

  if (node.layoutMode === "HORIZONTAL") {
    node.primaryAxisSizingMode = "FIXED"
  } else if (node.layoutMode === "VERTICAL") {
    node.counterAxisSizingMode = "FIXED"
  }

  node.resize(width, Math.max(1, node.height))
}

export function convertFigmaNodeLayoutRecursively(node: SceneNode, direction: LayoutConversionDirection): void {
  if (isAutoLayoutSceneNode(node)) {
    const currentMode = node.layoutMode
    const shouldConvert = direction === "row-to-column"
      ? currentMode === "HORIZONTAL"
      : currentMode === "VERTICAL"

    if (shouldConvert) {
      const primarySizing = node.primaryAxisSizingMode
      const counterSizing = node.counterAxisSizingMode
      node.layoutMode = direction === "row-to-column" ? "VERTICAL" : "HORIZONTAL"
      node.primaryAxisSizingMode = primarySizing
      node.counterAxisSizingMode = counterSizing
    }
  }

  if ("children" in node) {
    for (const child of node.children) convertFigmaNodeLayoutRecursively(child, direction)
  }
}

async function exportConvertedJsonFrame(frame: FigmaSerializedFrame) {
  const created = await createSceneNodeFromSerializedNode(frame, null, true)
  if (!isImportableFrameNode(created)) throw new Error("JSON root must resolve to a frame.")

  const [selected] = figma.currentPage.selection
  const sourceRight = selected && "x" in selected && "width" in selected
    ? selected.x + selected.width
    : figma.viewport.center.x
  created.x = sourceRight + 80
  created.y = selected && "y" in selected ? selected.y : figma.viewport.center.y - created.height / 2
  figma.currentPage.appendChild(created)
  figma.currentPage.selection = [created]
  figma.viewport.scrollAndZoomIntoView([created])
  figma.notify(`Created "${created.name}" with Auto Layout preserved.`)
}

async function createSceneNodeFromSerializedNode(
  serialized: FigmaSerializedNode,
  parent: BaseNode & ChildrenMixin | null,
  isRoot = false
): Promise<SceneNode> {
  const node = await createBaseSceneNode(serialized)
  applyCommonProperties(node, serialized)

  if (parent) parent.appendChild(node)

  if (isAutoLayoutSceneNode(node)) {
    applyContainerLayoutBeforeChildren(node, serialized)
  }

  if ("children" in node) {
    for (const child of serialized.children) {
      await createSceneNodeFromSerializedNode(child, node)
    }
  }

  applyGeometryAfterChildren(node, serialized, parent, isRoot)
  applyChildLayoutProperties(node, serialized, parent)
  return node
}

async function createBaseSceneNode(serialized: FigmaSerializedNode): Promise<SceneNode> {
  if (serialized.type === "TEXT") {
    const node = figma.createText()
    await applyText(node, serialized)
    return node
  }
  if (serialized.type === "RECTANGLE") return figma.createRectangle()
  if (serialized.type === "ELLIPSE") return figma.createEllipse()
  if (serialized.type === "LINE") return figma.createLine()
  if (serialized.type === "VECTOR") return figma.createVector()
  if (serialized.type === "POLYGON") return figma.createPolygon()
  if (serialized.type === "STAR") return figma.createStar()
  return figma.createFrame()
}

function applyCommonProperties(node: SceneNode, serialized: FigmaSerializedNode) {
  node.name = serialized.name
  node.visible = serialized.visible
  node.locked = serialized.locked

  if ("rotation" in node) node.rotation = serialized.geometry.rotation
  if ("opacity" in node && typeof serialized.style.opacity === "number") node.opacity = clamp(serialized.style.opacity, 0, 1)
  if ("fills" in node) {
    const fills = toReadonlyArray<Paint>(serialized.style.fills)
    if (fills) node.fills = fills
  }
  if ("strokes" in node) {
    const strokes = toReadonlyArray<Paint>(serialized.style.strokes)
    if (strokes) node.strokes = strokes
  }
  if ("strokeWeight" in node && typeof serialized.style.strokeWeight === "number") node.strokeWeight = serialized.style.strokeWeight
  if ("effects" in node) {
    const effects = toReadonlyArray<Effect>(serialized.style.effects)
    if (effects) node.effects = effects
  }
  if ("cornerRadius" in node && typeof serialized.style.cornerRadius === "number") node.cornerRadius = serialized.style.cornerRadius
}

async function applyText(node: TextNode, serialized: FigmaSerializedNode) {
  const desired = toFontName(serialized.text?.fontName) ?? { family: "Inter", style: "Regular" }
  let font = desired
  try {
    await figma.loadFontAsync(font)
  } catch {
    font = { family: "Inter", style: "Regular" }
    await figma.loadFontAsync(font)
  }
  node.fontName = font
  node.characters = serialized.text?.characters ?? ""
  if (typeof serialized.text?.fontSize === "number") node.fontSize = serialized.text.fontSize
  if (isHorizontalTextAlign(serialized.text?.textAlignHorizontal)) node.textAlignHorizontal = serialized.text.textAlignHorizontal
  if (isVerticalTextAlign(serialized.text?.textAlignVertical)) node.textAlignVertical = serialized.text.textAlignVertical
  const lineHeight = toLineHeight(serialized.text?.lineHeight)
  if (lineHeight) node.lineHeight = lineHeight
}

function applyContainerLayoutBeforeChildren(node: AutoLayoutSceneNode, serialized: FigmaSerializedNode) {
  const mode = readSerializedLayoutMode(serialized)
  node.layoutMode = mode === "HORIZONTAL" || mode === "VERTICAL" ? mode : "NONE"
  if (node.layoutMode === "NONE") return

  const padding = serialized.layout.padding
  if (padding) {
    node.paddingTop = Math.max(0, padding.top)
    node.paddingRight = Math.max(0, padding.right)
    node.paddingBottom = Math.max(0, padding.bottom)
    node.paddingLeft = Math.max(0, padding.left)
  }
  node.itemSpacing = clamp(serialized.layout.itemSpacing ?? 0, 0, 1000)
  node.primaryAxisAlignItems = toAxisAlign(serialized.layout.primaryAxisAlignItems)
  node.counterAxisAlignItems = toCounterAlign(serialized.layout.counterAxisAlignItems)
  node.primaryAxisSizingMode = toAxisSizing(serialized.layout.primaryAxisSizingMode)
  node.counterAxisSizingMode = toAxisSizing(serialized.layout.counterAxisSizingMode)
  if ("layoutWrap" in node && (serialized.layout.layoutWrap === "WRAP" || serialized.layout.layoutWrap === "NO_WRAP")) {
    node.layoutWrap = serialized.layout.layoutWrap
  }
}

function applyGeometryAfterChildren(
  node: SceneNode,
  serialized: FigmaSerializedNode,
  parent: (BaseNode & ChildrenMixin) | null,
  isRoot: boolean
) {
  const parentIsAutoLayout = parent != null && isAutoLayoutSceneNode(parent) && parent.layoutMode !== "NONE"
  if (!parentIsAutoLayout || isRoot) {
    node.x = serialized.geometry.x
    node.y = serialized.geometry.y
  }

  if (!("resize" in node)) return
  const width = Math.max(1, serialized.geometry.width)
  const height = Math.max(1, serialized.geometry.height)

  if (isAutoLayoutSceneNode(node) && node.layoutMode !== "NONE") {
    const horizontalFixed = serialized.layout.layoutSizingHorizontal === "FIXED" || axisIsFixed(node, "horizontal")
    const verticalFixed = serialized.layout.layoutSizingVertical === "FIXED" || axisIsFixed(node, "vertical")
    const nextWidth = horizontalFixed ? width : node.width
    const nextHeight = verticalFixed ? height : node.height
    if (horizontalFixed || verticalFixed) node.resize(Math.max(1, nextWidth), Math.max(1, nextHeight))
    return
  }

  node.resize(width, height)
}

function applyChildLayoutProperties(node: SceneNode, serialized: FigmaSerializedNode, parent: (BaseNode & ChildrenMixin) | null) {
  if (!parent || !isAutoLayoutSceneNode(parent) || parent.layoutMode === "NONE") return

  if ("layoutAlign" in node && (serialized.layout.layoutAlign === "INHERIT" || serialized.layout.layoutAlign === "STRETCH")) {
    node.layoutAlign = serialized.layout.layoutAlign
  }
  if ("layoutGrow" in node && typeof serialized.layout.layoutGrow === "number") node.layoutGrow = Math.max(0, serialized.layout.layoutGrow)
  if ("layoutSizingHorizontal" in node && isLayoutSizing(serialized.layout.layoutSizingHorizontal)) {
    try { node.layoutSizingHorizontal = serialized.layout.layoutSizingHorizontal } catch {}
  }
  if ("layoutSizingVertical" in node && isLayoutSizing(serialized.layout.layoutSizingVertical)) {
    try { node.layoutSizingVertical = serialized.layout.layoutSizingVertical } catch {}
  }
}

function axisIsFixed(node: AutoLayoutSceneNode, axis: "horizontal" | "vertical"): boolean {
  if (node.layoutMode === "HORIZONTAL") return axis === "horizontal" ? node.primaryAxisSizingMode === "FIXED" : node.counterAxisSizingMode === "FIXED"
  return axis === "vertical" ? node.primaryAxisSizingMode === "FIXED" : node.counterAxisSizingMode === "FIXED"
}

function serializeFrame(node: ImportableFrameNode): FigmaSerializedFrame {
  const rootBounds = getAbsoluteBounds(node)
  return {
    ...serializeNode(node, rootBounds, null, null, 0, 0, 1),
    type: node.type,
    schemaVersion: 1,
    importedAt: new Date().toISOString()
  }
}

function serializeNode(
  node: SceneNode,
  rootBounds: Bounds,
  parentBounds: Bounds | null,
  parentId: string | null,
  depth: number,
  siblingIndex: number,
  siblingCount: number
): FigmaSerializedNode {
  const absolute = getAbsoluteBounds(node)
  const parentRelative = relativeBounds(absolute, parentBounds ?? absolute)
  const rootRelative = relativeBounds(absolute, rootBounds)
  return {
    id: node.id,
    originalFigmaId: node.id,
    name: node.name,
    type: node.type,
    visible: "visible" in node ? node.visible : true,
    locked: "locked" in node ? node.locked : false,
    geometry: {
      x: "x" in node ? node.x : 0,
      y: "y" in node ? node.y : 0,
      width: "width" in node ? node.width : 1,
      height: "height" in node ? node.height : 1,
      rotation: "rotation" in node ? node.rotation : 0,
      absoluteBounds: absolute,
      parentRelativeBounds: parentRelative,
      rootRelativeBounds: rootRelative,
      percentOfParent: parentBounds ? percentBounds(parentRelative, parentBounds) : undefined,
      percentOfRoot: percentBounds(rootRelative, rootBounds),
      hierarchy: { parentId, depth, siblingIndex, siblingCount }
    },
    layout: serializeLayout(node),
    style: serializeStyle(node),
    text: node.type === "TEXT" ? serializeText(node) : undefined,
    children: "children" in node
      ? node.children.map((child, index) => serializeNode(child, rootBounds, absolute, node.id, depth + 1, index, node.children.length))
      : []
  }
}

function serializeLayout(node: SceneNode): FigmaSerializedNode["layout"] {
  const layout: FigmaSerializedNode["layout"] = { isAutoLayout: isAutoLayoutSceneNode(node) && node.layoutMode !== "NONE" }
  if ("layoutMode" in node) { layout.layoutMode = node.layoutMode; layout.autoLayoutDirection = node.layoutMode }
  if ("constraints" in node) layout.constraints = toJson(node.constraints)
  if ("layoutAlign" in node) layout.layoutAlign = node.layoutAlign
  if ("layoutGrow" in node) layout.layoutGrow = node.layoutGrow
  if ("layoutSizingHorizontal" in node) layout.layoutSizingHorizontal = node.layoutSizingHorizontal
  if ("layoutSizingVertical" in node) layout.layoutSizingVertical = node.layoutSizingVertical
  if (isAutoLayoutSceneNode(node)) {
    layout.itemSpacing = node.itemSpacing
    layout.primaryAxisAlignItems = node.primaryAxisAlignItems
    layout.counterAxisAlignItems = node.counterAxisAlignItems
    layout.primaryAxisSizingMode = node.primaryAxisSizingMode
    layout.counterAxisSizingMode = node.counterAxisSizingMode
    layout.layoutWrap = node.layoutWrap
    layout.padding = { top: node.paddingTop, right: node.paddingRight, bottom: node.paddingBottom, left: node.paddingLeft }
  }
  return layout
}

function serializeStyle(node: SceneNode): FigmaSerializedNode["style"] {
  const style: FigmaSerializedNode["style"] = {}
  if ("opacity" in node) style.opacity = node.opacity
  if ("blendMode" in node) style.blendMode = node.blendMode
  if ("fills" in node && node.fills !== figma.mixed) style.fills = toJson(node.fills)
  if ("strokes" in node) style.strokes = toJson(node.strokes)
  if ("strokeWeight" in node && node.strokeWeight !== figma.mixed) style.strokeWeight = node.strokeWeight
  if ("cornerRadius" in node) style.cornerRadius = node.cornerRadius === figma.mixed ? "mixed" : node.cornerRadius
  if ("effects" in node) style.effects = toJson(node.effects)
  return style
}

function serializeText(node: TextNode): FigmaSerializedNode["text"] {
  return {
    characters: node.characters,
    fontSize: node.fontSize === figma.mixed ? "mixed" : node.fontSize,
    fontName: toJson(node.fontName),
    fontWeight: node.fontWeight === figma.mixed ? undefined : node.fontWeight,
    textAlignHorizontal: node.textAlignHorizontal,
    textAlignVertical: node.textAlignVertical,
    lineHeight: toJson(node.lineHeight),
    letterSpacing: toJson(node.letterSpacing)
  }
}

function isImportableFrameNode(node: BaseNode): node is ImportableFrameNode {
  return node.type === "FRAME" || node.type === "COMPONENT" || node.type === "INSTANCE"
}
function isAutoLayoutSceneNode(node: SceneNode | BaseNode): node is AutoLayoutSceneNode {
  return node.type === "FRAME" || node.type === "COMPONENT" || node.type === "INSTANCE"
}
function readSerializedLayoutMode(node: FigmaSerializedNode): "NONE" | "HORIZONTAL" | "VERTICAL" | "GRID" {
  const value = node.layout.layoutMode ?? node.layout.autoLayoutDirection
  return value === "HORIZONTAL" || value === "VERTICAL" || value === "GRID" ? value : "NONE"
}
function toAxisSizing(value?: string): "FIXED" | "AUTO" { return value === "FIXED" ? "FIXED" : "AUTO" }
function toAxisAlign(value?: string): "MIN" | "CENTER" | "MAX" | "SPACE_BETWEEN" {
  return value === "CENTER" || value === "MAX" || value === "SPACE_BETWEEN" ? value : "MIN"
}
function toCounterAlign(value?: string): "MIN" | "CENTER" | "MAX" | "BASELINE" {
  return value === "CENTER" || value === "MAX" || value === "BASELINE" ? value : "MIN"
}
function isLayoutSizing(value?: string): value is "FIXED" | "HUG" | "FILL" { return value === "FIXED" || value === "HUG" || value === "FILL" }
function isHorizontalTextAlign(value?: string): value is "LEFT" | "CENTER" | "RIGHT" | "JUSTIFIED" { return value === "LEFT" || value === "CENTER" || value === "RIGHT" || value === "JUSTIFIED" }
function isVerticalTextAlign(value?: string): value is "TOP" | "CENTER" | "BOTTOM" { return value === "TOP" || value === "CENTER" || value === "BOTTOM" }

function toFontName(value: FigmaJsonValue | undefined): FontName | null {
  if (!value || Array.isArray(value) || typeof value !== "object") return null
  const family = value.family
  const style = value.style
  return typeof family === "string" && typeof style === "string" ? { family, style } : null
}
function toLineHeight(value: FigmaJsonValue | undefined): LineHeight | null {
  if (!value || Array.isArray(value) || typeof value !== "object") return null
  if (value.unit === "AUTO") return { unit: "AUTO" }
  if ((value.unit === "PIXELS" || value.unit === "PERCENT") && typeof value.value === "number") return { unit: value.unit, value: value.value }
  return null
}
function toReadonlyArray<T>(value: FigmaJsonValue | undefined): readonly T[] | null {
  return Array.isArray(value) ? value as unknown as readonly T[] : null
}
function toJson(value: unknown): FigmaJsonValue { return JSON.parse(JSON.stringify(value)) as FigmaJsonValue }
function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, value)) }

function getAbsoluteBounds(node: SceneNode): Bounds {
  const box = node.absoluteBoundingBox
  const x = box?.x ?? ("x" in node ? node.x : 0)
  const y = box?.y ?? ("y" in node ? node.y : 0)
  const width = box?.width ?? ("width" in node ? node.width : 1)
  const height = box?.height ?? ("height" in node ? node.height : 1)
  return makeBounds(x, y, width, height)
}
function relativeBounds(value: Bounds, origin: Bounds): Bounds { return makeBounds(value.x - origin.x, value.y - origin.y, value.width, value.height) }
function makeBounds(x: number, y: number, width: number, height: number): Bounds {
  return { x, y, width, height, right: x + width, bottom: y + height, centerX: x + width / 2, centerY: y + height / 2 }
}
function percentBounds(value: Bounds, reference: Bounds) {
  const width = Math.max(1, reference.width)
  const height = Math.max(1, reference.height)
  return { x: value.x / width, y: value.y / height, width: value.width / width, height: value.height / height, right: value.right / width, bottom: value.bottom / height }
}
function sendToUi(message: PluginToUiMessage) { figma.ui.postMessage(message) }

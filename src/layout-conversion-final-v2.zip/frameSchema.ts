export type FigmaJsonPrimitive = string | number | boolean | null
export type FigmaJsonValue = FigmaJsonPrimitive | FigmaJsonValue[] | { [key: string]: FigmaJsonValue }

export type LayoutConversionDirection = "row-to-column" | "column-to-row"

export type SerializedSpacing = { top: number; right: number; bottom: number; left: number }

export type FigmaSerializedNodeV1 = {
  id: string
  originalFigmaId?: string
  name: string
  type: string
  responsive?: { [key: string]: FigmaJsonValue | undefined }
  visible: boolean
  locked: boolean
  geometry: {
    x: number
    y: number
    width: number
    height: number
    rotation: number
    absoluteBounds: Bounds
    parentRelativeBounds: Bounds
    rootRelativeBounds: Bounds
    percentOfParent?: PercentBounds
    percentOfRoot: PercentBounds
    hierarchy: { parentId: string | null; depth: number; siblingIndex: number; siblingCount: number }
  }
  layout: {
    isAutoLayout: boolean
    autoLayoutDirection?: "NONE" | "HORIZONTAL" | "VERTICAL" | "GRID"
    constraints?: FigmaJsonValue
    layoutMode?: string
    layoutAlign?: string
    layoutGrow?: number
    layoutSizingHorizontal?: string
    layoutSizingVertical?: string
    itemSpacing?: number
    counterAxisSpacing?: number
    primaryAxisAlignItems?: string
    counterAxisAlignItems?: string
    layoutWrap?: string
    padding?: SerializedSpacing
    margin?: SerializedSpacing
    primaryAxisSizingMode?: string
    counterAxisSizingMode?: string
  }
  style: {
    opacity?: number
    blendMode?: string
    fills?: FigmaJsonValue
    strokes?: FigmaJsonValue
    strokeWeight?: number
    cornerRadius?: number | string
    effects?: FigmaJsonValue
  }
  text?: {
    characters: string
    fontSize?: number | string
    fontName?: FigmaJsonValue
    fontWeight?: number
    textAlignHorizontal?: string
    textAlignVertical?: string
    lineHeight?: FigmaJsonValue
    letterSpacing?: FigmaJsonValue
  }
  component?: FigmaJsonValue
  instance?: FigmaJsonValue
  metadata?: { [key: string]: FigmaJsonValue }
  children: FigmaSerializedNodeV1[]
}

type Bounds = { x: number; y: number; width: number; height: number; right: number; bottom: number; centerX: number; centerY: number }
type PercentBounds = { x: number; y: number; width: number; height: number; right: number; bottom: number }

export type FigmaSerializedFrameV1 = FigmaSerializedNodeV1 & {
  type: "FRAME" | "COMPONENT" | "INSTANCE"
  schemaVersion: 1
  importedAt: string
}
export type FigmaSerializedNode = FigmaSerializedNodeV1
export type FigmaSerializedFrame = FigmaSerializedFrameV1

export type NormalizedLayoutMode = "NONE" | "HORIZONTAL" | "VERTICAL" | "GRID"
export type NormalizedNodeGeometry = { x: number; y: number; width: number; height: number; rotation?: number }
export type NormalizedNodeLayout = {
  isAutoLayout?: boolean
  mode?: NormalizedLayoutMode
  constraints?: FigmaJsonValue
  horizontalSizing?: string
  verticalSizing?: string
  grow?: number
  align?: string
  gap?: number
  counterGap?: number
  primaryAlign?: string
  counterAlign?: string
  wrap?: boolean
  padding?: SerializedSpacing
  margin?: SerializedSpacing
  primarySizing?: string
  counterSizing?: string
}
export type NormalizedNodeStyle = {
  opacity?: number
  blendMode?: string
  fills?: FigmaJsonValue
  strokes?: FigmaJsonValue
  strokeWeight?: number
  cornerRadius?: number | string
  effects?: FigmaJsonValue
}
export type NormalizedFigmaNode = {
  id: string
  originalFigmaId?: string
  name: string
  type: string
  visible?: boolean
  locked?: boolean
  geometry: NormalizedNodeGeometry
  layout?: NormalizedNodeLayout
  style?: NormalizedNodeStyle
  styleRef?: string
  text?: FigmaSerializedNodeV1["text"] | null
  responsive?: FigmaSerializedNodeV1["responsive"]
  component?: FigmaJsonValue
  instance?: FigmaJsonValue
  metadata?: { [key: string]: FigmaJsonValue }
  children?: NormalizedFigmaNode[]
}
export type NormalizedFigmaFrame = NormalizedFigmaNode & { type: "FRAME" | "COMPONENT" | "INSTANCE" }
export type NormalizedFigmaDocument = { schemaVersion: 2; root: NormalizedFigmaFrame; styles?: { [key: string]: NormalizedNodeStyle } }
export type ValidationIssue = { path: string; message: string }
export type ValidationResult<T> = { ok: true; value: T; warnings: string[] } | { ok: false; errors: ValidationIssue[]; warnings: string[] }

export type PluginToUiMessage =
  | { type: "frame-imported"; payload: FigmaSerializedFrame }
  | { type: "import-error"; message: string }

export type UiToPluginMessage =
  | { type: "import-selected-frame" }
  | { type: "convert-and-export-frame"; payload: { sourceFrameId: string; direction: LayoutConversionDirection } }
  | { type: "export-converted-json-frame"; payload: { frame: FigmaSerializedFrame } }
